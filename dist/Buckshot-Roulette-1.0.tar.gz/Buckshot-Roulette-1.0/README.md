# Buckshot Roulette 恶魔轮盘赌
## 开发环境
- linux ubuntu 22.04（主要开发环境，负责运行代码等等）
- apple mac 14.0（主要是使用mac上自带的“预览”来测量图片并使用PIL.Image进行切割、缩放等操作）
其实ubuntu在网上也有测像素的工具，但我懒得找了......
正好家里有台mac，就选择用mac完成。
## 改动说明
## 0.1
- 使用类初步实现了游戏
- 可玩性不高
### 1.0
- 增加道具
- 增加两个回合
- 增加图形界面（pygame）

## 程序说明
- 你可以看到在每个.py文件开头简短的说明
### asset
- 你可能注意到gun.png是一张空白图片，因为它只用于绘制边框（届时ALPHA值将设为255（完全透明））

# Levolet Inc.
### CC-BY-SA 3.0 protocol
### Python3.10.12